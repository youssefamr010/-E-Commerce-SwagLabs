package com.demo.seleniumTestNG;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


public class demoTestNG {
    WebDriver auto = new ChromeDriver();

    @BeforeTest
    public void openBrowser() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Downloads\\chromedriver-win64\\chromedriver.exe");
        auto.manage().window().maximize();
        auto.navigate().to("https://www.saucedemo.com/");
    }

    @Test
    public void loginStandardUser() {
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("standard_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();

        String logoText = auto.findElement(By.className("app_logo")).getText();
        assert logoText.equals("Swag Labs") : "Standard user login passed";

        String currentUrl = auto.getCurrentUrl();
        assert currentUrl.equals("https://www.saucedemo.com/inventory.html") ;
    }

    @Test
    public void loginLockedOutUser() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("locked_out_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginProblemUser() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("problem_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();

        String currentUrl = auto.getCurrentUrl();
        assert currentUrl.equals("https://www.saucedemo.com/inventory.html") ;
    }

    @Test
    public void loginPerformanceGlitchUser() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("performance_glitch_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();

        String currentUrl = auto.getCurrentUrl();
        assert currentUrl.equals("https://www.saucedemo.com/inventory.html") ;
    }

    @Test
    public void loginErrorUser() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("error_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();

        String currentUrl = auto.getCurrentUrl();
        assert currentUrl.equals("https://www.saucedemo.com/inventory.html") ;
    }

    @Test
    public void loginVisualUser() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("visual_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();

        String currentUrl = auto.getCurrentUrl();
        assert currentUrl.equals("https://www.saucedemo.com/inventory.html") ;
    }

    // Invalid Test Cases

    @Test
    public void loginEmptyFields() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginSpacesOnly() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("    ");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("    ");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginSpecialCharsUsernameValidPassword() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("!@#$%");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("secret_sauce");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginValidUsernameInvalidPassword() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("standard_user");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("%^&*(");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginSpecialCharsBothFields() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("#$%^");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("&*()");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginNumbersInBothFields() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys("12345");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys("67890");

        auto.findElement(By.id("login-button")).click();


    }

    @Test
    public void loginValidUserPasswordWithSpaces() {
        auto.navigate().refresh();
        WebElement username = auto.findElement(By.id("user-name"));
        username.sendKeys(" standard_user ");

        WebElement password = auto.findElement(By.id("password"));
        password.sendKeys(" secret_sauce ");

        auto.findElement(By.id("login-button")).click();

    }
}


